show databases;
